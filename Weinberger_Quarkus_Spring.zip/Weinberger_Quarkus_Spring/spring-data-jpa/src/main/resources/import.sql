INSERT INTO car(id, model, brand, HP) VALUES (1, 'Kadett', 'Opel',125);
INSERT INTO car(id, model, brand, HP) VALUES (2, 'Felicia', 'Skoda',54);
