package at.htl.quarkus.spring;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeCarResourceIT extends CarResourceTest {

    // Execute the same tests but in native mode.
}