package at.htl.quarkus.spring;

import java.util.function.Function;

public interface StringFunction extends Function<String, String> {
}
